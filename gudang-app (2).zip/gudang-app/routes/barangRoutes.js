const express = require('express');
const router = express.Router();
const Barang = require('../models/Barang');

// GET semua barang
router.get('/', async (req, res) => {
  const data = await Barang.find();
  res.json(data);
});

// POST barang baru
router.post('/', async (req, res) => {
  const newBarang = new Barang(req.body);
  await newBarang.save();
  res.json(newBarang);
});

// PUT update barang
router.put('/:id', async (req, res) => {
  const updated = await Barang.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// DELETE barang
router.delete('/:id', async (req, res) => {
  await Barang.findByIdAndDelete(req.params.id);
  res.json({ message: 'Barang deleted' });
});

module.exports = router;
