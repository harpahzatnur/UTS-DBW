const mongoose = require('mongoose');

const BarangSchema = new mongoose.Schema({
  nama: String,
  jumlah: Number,
  lokasi: String
});

module.exports = mongoose.model('Barang', BarangSchema);
