const barangList = document.getElementById('barangList');
const form = document.getElementById('barangForm');

const fetchBarang = async () => {
  const res = await fetch('/api/barang');
  const data = await res.json();
  barangList.innerHTML = '';
  data.forEach(b => {
    const li = document.createElement('li');
    li.innerHTML = `
      ${b.nama} - ${b.jumlah} pcs di ${b.lokasi}
      <button onclick="hapusBarang('${b._id}')">Hapus</button>
    `;
    barangList.appendChild(li);
  });
};

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const nama = document.getElementById('nama').value;
  const jumlah = document.getElementById('jumlah').value;
  const lokasi = document.getElementById('lokasi').value;

  await fetch('/api/barang', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nama, jumlah, lokasi })
  });

  form.reset();
  fetchBarang();
});

const hapusBarang = async (id) => {
  await fetch(`/api/barang/${id}`, { method: 'DELETE' });
  fetchBarang();
};

fetchBarang();
